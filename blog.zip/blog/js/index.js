$(function(){
      	  var user = "<%=session.getAttribute('user')%>";
      	  if(user!="null"){
      		  var center = document.getElementById("message");
      		  var setting = document.getElementById("settings");
	        	  var exit = document.getElementById("exit");
	        	  center.style.display='none';
	        	  exit.style.display='none';
	        	  settings.style.display='none';
            }else{
	        	  var register=document.getElementById("register");
			      var login=document.getElementById("login");
			      register.style.display='none';
			      login.style.display='none';
            }
})

